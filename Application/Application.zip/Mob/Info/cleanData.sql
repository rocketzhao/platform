DROP TABLE IF EXISTS `ocenter_mob_channel`;
