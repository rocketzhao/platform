<?php
return array(
    'login'=>'Login',
    'forget_password'=>'Forgot password？',
    'quick_login'=>'Register',
    'found'=>'Found',
    'password'=>'Password',
    'comment'=>'Comment',
    'username'=>'UserName',
    'email'=>'E-Mail',
    'phone_number'=>'Phone',
    'weibo'=>'Weibo',
    'blog'=>'Blog',
    'forum'=>'Forum',
    'event'=>'Event',
    'group'=>'Group',
    'shop'=>'Shop',
    'addweibo'=>'Addweibo',
    'myfocus'=>'Myfocus',
    'weibodetail'=>'Weibodetail',
    'validate_code'=>'Validate_code',
    'blogtype' => 'Blogtype',

    'myblog' => 'Myblog',
    'blogdetail' => 'Blogdetail',
    'message'=>'Message'
);