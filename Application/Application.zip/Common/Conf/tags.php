<?php
return array(
	'app_init'=>array('Common\Behavior\InitHookBehavior'),
    'action_begin'=>array('Common\Behavior\InitModuleInfoBehavior')
);