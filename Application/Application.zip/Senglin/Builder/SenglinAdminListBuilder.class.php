<?php


namespace Senglin\Builder;
use Admin\Builder\AdminListBuilder;

class SenglinAdminListBuilder extends AdminListBuilder
{
   

}